# fireshare
Simple Photo Sharing with Ionic + Firebase

These files are only src folder files

you have to create new ionic project with "ionic start folder_name or app_name"

within this project you will find src folder
